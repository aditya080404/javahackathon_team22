package com.wildlife.ui_service;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.wildlife.ui_service.model.Resource;

@Controller
@RequestMapping("/resources")
public class ResourceController {

    private final RestTemplate restTemplate;

    @Value("${backend.field.url:http://localhost:8084}")
    private String fieldUrl;

    public ResourceController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping
    public String getAllResources(Model model) {
        try {
            Resource[] list = restTemplate.getForObject(
                    fieldUrl + "/resources/api/all",
                    Resource[].class
            );
            model.addAttribute("resources", list != null ? Arrays.asList(list) : Collections.emptyList());
        } catch (Exception e) {
            model.addAttribute("resources", Collections.emptyList());
        }
        model.addAttribute("resource", new Resource());
        return "resources";
    }

    @PostMapping("/api")
    @ResponseBody
    public ResponseEntity<String> addResource(@RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.postForEntity(fieldUrl + "/resources/api", entity, String.class);
    }

    @GetMapping("/{id}")
    @ResponseBody
    public ResponseEntity<String> getResourceById(@PathVariable long id) {
        try {
            return restTemplate.getForEntity(fieldUrl + "/resources/" + id, String.class);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    @ResponseBody
    public ResponseEntity<String> updateResource(@PathVariable long id, @RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.exchange(fieldUrl + "/resources/" + id, HttpMethod.PUT, entity, String.class);
    }

    @DeleteMapping("/{id}")
    @ResponseBody
    public ResponseEntity<String> deleteResource(@PathVariable long id) {
        return restTemplate.exchange(fieldUrl + "/resources/" + id, HttpMethod.DELETE, null, String.class);
    }
}

