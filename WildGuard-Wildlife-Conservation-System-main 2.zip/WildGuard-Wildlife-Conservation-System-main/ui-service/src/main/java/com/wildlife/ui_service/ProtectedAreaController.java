package com.wildlife.ui_service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@Controller
public class ProtectedAreaController {

    private final RestTemplate restTemplate;

    @Value("${backend.wildlife.url:http://localhost:8081}")
    private String wildlifeUrl;

    public ProtectedAreaController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping({"/protected-areas", "/api/protected-areas"})
    public String protectedAreasPage() {
        return "protected-areas";
    }

    @GetMapping("/api/protected-areas/all")
    @ResponseBody
    public ResponseEntity<String> getAllAreas() {
        try {
            return restTemplate.getForEntity(wildlifeUrl + "/api/protected-areas/all", String.class);
        } catch (Exception e) {
            return ResponseEntity.ok("[]");
        }
    }

    @GetMapping("/api/protected-areas/{id}")
    @ResponseBody
    public ResponseEntity<String> getAreaById(@PathVariable long id) {
        try {
            return restTemplate.getForEntity(wildlifeUrl + "/api/protected-areas/" + id, String.class);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/api/protected-areas")
    @ResponseBody
    public ResponseEntity<String> addArea(@RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.postForEntity(wildlifeUrl + "/api/protected-areas", entity, String.class);
    }

    @PutMapping("/api/protected-areas/{id}")
    @ResponseBody
    public ResponseEntity<String> updateArea(@PathVariable long id, @RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.exchange(wildlifeUrl + "/api/protected-areas/" + id, HttpMethod.PUT, entity, String.class);
    }

    @DeleteMapping("/api/protected-areas/{id}")
    @ResponseBody
    public ResponseEntity<String> deleteArea(@PathVariable long id) {
        return restTemplate.exchange(wildlifeUrl + "/api/protected-areas/" + id, HttpMethod.DELETE, null, String.class);
    }

    @GetMapping("/api/protected-areas/zones")
    @ResponseBody
    public ResponseEntity<String> getAllZones() {
        try {
            return restTemplate.getForEntity(wildlifeUrl + "/api/protected-areas/zones", String.class);
        } catch (Exception e) {
            return ResponseEntity.ok("[]");
        }
    }

    @GetMapping("/api/protected-areas/{areaId}/zones")
    @ResponseBody
    public ResponseEntity<String> getZonesByAreaId(@PathVariable long areaId) {
        try {
            return restTemplate.getForEntity(wildlifeUrl + "/api/protected-areas/" + areaId + "/zones", String.class);
        } catch (Exception e) {
            return ResponseEntity.ok("[]");
        }
    }

    @GetMapping("/api/protected-areas/zones/{zoneId}")
    @ResponseBody
    public ResponseEntity<String> getZoneById(@PathVariable long zoneId) {
        try {
            return restTemplate.getForEntity(wildlifeUrl + "/api/protected-areas/zones/" + zoneId, String.class);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/api/protected-areas/zones")
    @ResponseBody
    public ResponseEntity<String> addZone(@RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.postForEntity(wildlifeUrl + "/api/protected-areas/zones", entity, String.class);
    }

    @PutMapping("/api/protected-areas/zones/{zoneId}")
    @ResponseBody
    public ResponseEntity<String> updateZone(@PathVariable long zoneId, @RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.exchange(wildlifeUrl + "/api/protected-areas/zones/" + zoneId, HttpMethod.PUT, entity, String.class);
    }

    @DeleteMapping("/api/protected-areas/zones/{zoneId}")
    @ResponseBody
    public ResponseEntity<String> deleteZone(@PathVariable long zoneId) {
        return restTemplate.exchange(wildlifeUrl + "/api/protected-areas/zones/" + zoneId, HttpMethod.DELETE, null, String.class);
    }
}

