package com.wildlife.ui_service;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.wildlife.ui_service.model.Staff;

@Controller
@RequestMapping("/staff")
public class StaffController {

    private final RestTemplate restTemplate;

    @Value("${backend.field.url:http://localhost:8084}")
    private String fieldUrl;

    public StaffController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping
    public String getAllStaff(Model model) {
        try {
            Staff[] list = restTemplate.getForObject(
                    fieldUrl + "/staff/api/all",
                    Staff[].class
            );
            model.addAttribute("staffList", list != null ? Arrays.asList(list) : Collections.emptyList());
        } catch (Exception e) {
            model.addAttribute("staffList", Collections.emptyList());
        }
        model.addAttribute("staff", new Staff());
        return "staff";
    }

    @PostMapping
    public String addStaff(@RequestParam MultiValueMap<String, String> formData) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);
            restTemplate.postForEntity(fieldUrl + "/staff", request, String.class);
            return "redirect:/staff?success";
        } catch (Exception e) {
            return "redirect:/staff?error";
        }
    }

    @PostMapping("/update/{id}")
    public String updateStaff(@PathVariable long id, @RequestParam MultiValueMap<String, String> formData) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);
            restTemplate.postForEntity(fieldUrl + "/staff/update/" + id, request, String.class);
            return "redirect:/staff?updated";
        } catch (Exception e) {
            return "redirect:/staff?error";
        }
    }

    @PostMapping("/delete/{id}")
    public String deleteStaff(@PathVariable long id) {
        try {
            restTemplate.postForEntity(fieldUrl + "/staff/delete/" + id, null, String.class);
            return "redirect:/staff?deleted";
        } catch (Exception e) {
            return "redirect:/staff?error";
        }
    }
}

