package com.wildlife.ui_service;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.wildlife.ui_service.model.Patrol;

@Controller
@RequestMapping("/patrols")
public class PatrolController {

    private final RestTemplate restTemplate;

    @Value("${backend.field.url:http://localhost:8084}")
    private String fieldUrl;

    public PatrolController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping
    public String showPatrols(Model model) {
        try {
            Patrol[] list = restTemplate.getForObject(
                    fieldUrl + "/patrols/api/all",
                    Patrol[].class
            );
            model.addAttribute("patrols", list != null ? Arrays.asList(list) : Collections.emptyList());
        } catch (Exception e) {
            model.addAttribute("patrols", Collections.emptyList());
        }
        model.addAttribute("patrol", new Patrol());
        return "patrols";
    }

    @PostMapping
    public String addPatrol(@RequestParam MultiValueMap<String, String> formData) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);
            restTemplate.postForEntity(fieldUrl + "/patrols", request, String.class);
            return "redirect:/patrols";
        } catch (Exception e) {
            return "redirect:/patrols?error";
        }
    }

    @PostMapping("/update/{id}")
    public String updatePatrol(@PathVariable long id, @RequestParam MultiValueMap<String, String> formData) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);
            restTemplate.postForEntity(fieldUrl + "/patrols/update/" + id, request, String.class);
            return "redirect:/patrols";
        } catch (Exception e) {
            return "redirect:/patrols?error";
        }
    }

    @PostMapping("/delete/{id}")
    public String deletePatrol(@PathVariable long id) {
        try {
            restTemplate.postForEntity(fieldUrl + "/patrols/delete/" + id, null, String.class);
            return "redirect:/patrols";
        } catch (Exception e) {
            return "redirect:/patrols?error";
        }
    }
}

