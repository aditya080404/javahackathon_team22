package com.wildlife.ui_service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@Controller
public class AnimalController {

    private final RestTemplate restTemplate;

    @Value("${backend.wildlife.url:http://localhost:8081}")
    private String wildlifeUrl;

    public AnimalController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/animals")
    public String animalsPage() {
        return "animals";
    }

    @GetMapping("/api/animals")
    @ResponseBody
    public ResponseEntity<String> getAllAnimals() {
        try {
            return restTemplate.getForEntity(wildlifeUrl + "/api/animals", String.class);
        } catch (Exception e) {
            return ResponseEntity.ok("[]");
        }
    }

    @GetMapping("/api/animals/{id}")
    @ResponseBody
    public ResponseEntity<String> getAnimalById(@PathVariable int id) {
        try {
            return restTemplate.getForEntity(wildlifeUrl + "/api/animals/" + id, String.class);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/api/animals")
    @ResponseBody
    public ResponseEntity<String> addAnimal(@RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.postForEntity(wildlifeUrl + "/api/animals", entity, String.class);
    }

    @PutMapping("/api/animals/{id}")
    @ResponseBody
    public ResponseEntity<String> updateAnimal(@PathVariable int id, @RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.exchange(wildlifeUrl + "/api/animals/" + id, HttpMethod.PUT, entity, String.class);
    }

    @DeleteMapping("/api/animals/{id}")
    @ResponseBody
    public ResponseEntity<String> deleteAnimal(@PathVariable int id) {
        return restTemplate.exchange(wildlifeUrl + "/api/animals/" + id, HttpMethod.DELETE, null, String.class);
    }
}

