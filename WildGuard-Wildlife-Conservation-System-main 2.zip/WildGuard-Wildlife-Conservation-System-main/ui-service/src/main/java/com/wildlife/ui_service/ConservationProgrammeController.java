package com.wildlife.ui_service;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.wildlife.ui_service.model.ConservationProgramme;

@Controller
@RequestMapping("/programmes")
public class ConservationProgrammeController {

    private final RestTemplate restTemplate;

    @Value("${backend.conservation.url:http://localhost:8082}")
    private String conservationUrl;

    public ConservationProgrammeController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping
    public String getAll(Model model) {
        try {
            ConservationProgramme[] programmes = restTemplate.getForObject(
                    conservationUrl + "/programmes/api/all",
                    ConservationProgramme[].class
            );
            model.addAttribute("programmes", programmes != null ? Arrays.asList(programmes) : Collections.emptyList());
        } catch (Exception e) {
            model.addAttribute("programmes", Collections.emptyList());
        }
        model.addAttribute("programme", new ConservationProgramme());
        return "programmes";
    }

    @PostMapping
    public String add(@RequestParam MultiValueMap<String, String> formData) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);
            restTemplate.postForEntity(conservationUrl + "/programmes", request, String.class);
            return "redirect:/programmes?success";
        } catch (Exception e) {
            return "redirect:/programmes?error";
        }
    }

    @PostMapping("/update/{id}")
    public String update(@PathVariable long id, @RequestParam MultiValueMap<String, String> formData) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);
            restTemplate.postForEntity(conservationUrl + "/programmes/update/" + id, request, String.class);
            return "redirect:/programmes?updated";
        } catch (Exception e) {
            return "redirect:/programmes?error";
        }
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable long id) {
        try {
            restTemplate.postForEntity(conservationUrl + "/programmes/delete/" + id, null, String.class);
            return "redirect:/programmes?deleted";
        } catch (Exception e) {
            return "redirect:/programmes?error";
        }
    }
}

