package com.wildlife.ui_service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.wildlife.ui_service.model.Incident;

@Controller
@RequestMapping("/incidents")
public class IncidentController {

    private final RestTemplate restTemplate;

    @Value("${backend.rescue.url:http://localhost:8083}")
    private String rescueUrl;

    public IncidentController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping
    public String showIncidentPage(Model model) {
        model.addAttribute("incident", new Incident());
        return "incidents";
    }

    @GetMapping("/all")
    @ResponseBody
    public ResponseEntity<String> getAllIncidents() {
        try {
            return restTemplate.getForEntity(rescueUrl + "/incidents/all", String.class);
        } catch (Exception e) {
            return ResponseEntity.ok("[]");
        }
    }

    @GetMapping("/{id}")
    @ResponseBody
    public ResponseEntity<String> getIncidentById(@PathVariable long id) {
        try {
            return restTemplate.getForEntity(rescueUrl + "/incidents/" + id, String.class);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    @ResponseBody
    public ResponseEntity<String> addIncident(@RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.postForEntity(rescueUrl + "/incidents", entity, String.class);
    }

    @PutMapping("/{id}")
    @ResponseBody
    public ResponseEntity<String> updateIncident(@PathVariable long id, @RequestBody String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body, headers);
        return restTemplate.exchange(rescueUrl + "/incidents/" + id, HttpMethod.PUT, entity, String.class);
    }

    @DeleteMapping("/{id}")
    @ResponseBody
    public ResponseEntity<String> deleteIncident(@PathVariable long id) {
        return restTemplate.exchange(rescueUrl + "/incidents/" + id, HttpMethod.DELETE, null, String.class);
    }
}

