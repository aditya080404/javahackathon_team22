package com.wildlife.ui_service;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.wildlife.ui_service.model.RescueCase;

@Controller
@RequestMapping("/rescues")
public class RescueCaseController {

    private final RestTemplate restTemplate;

    @Value("${backend.rescue.url:http://localhost:8083}")
    private String rescueUrl;

    public RescueCaseController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping
    public String getAllRescueCases(Model model) {
        try {
            RescueCase[] list = restTemplate.getForObject(
                    rescueUrl + "/rescues/api/all",
                    RescueCase[].class
            );
            model.addAttribute("rescueCases", list != null ? Arrays.asList(list) : Collections.emptyList());
        } catch (Exception e) {
            model.addAttribute("rescueCases", Collections.emptyList());
        }
        model.addAttribute("rescueCase", new RescueCase());
        return "rescues";
    }

    @PostMapping
    public String addRescueCase(@RequestParam MultiValueMap<String, String> formData) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);
            restTemplate.postForEntity(rescueUrl + "/rescues", request, String.class);
            return "redirect:/rescues?success";
        } catch (Exception e) {
            return "redirect:/rescues?error";
        }
    }

    @PostMapping("/update/{id}")
    public String updateRescueCase(@PathVariable long id, @RequestParam MultiValueMap<String, String> formData) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(formData, headers);
            restTemplate.postForEntity(rescueUrl + "/rescues/update/" + id, request, String.class);
            return "redirect:/rescues?updated";
        } catch (Exception e) {
            return "redirect:/rescues?error";
        }
    }

    @PostMapping("/delete/{id}")
    public String deleteRescueCase(@PathVariable long id) {
        try {
            restTemplate.postForEntity(rescueUrl + "/rescues/delete/" + id, null, String.class);
            return "redirect:/rescues?deleted";
        } catch (Exception e) {
            return "redirect:/rescues?error";
        }
    }
}

